## Reporting a Vulnerability

If you discover a security vulnerability within grunt, please submit a report via [huntr.dev](https://huntr.dev/bounties/?target=https%3A%2F%2Fgithub.com%2Fgruntjs%2Fgrunt). Bounties and CVEs are automatically managed and allocated via the platform.

All security vulnerabilities will be promptly addressed.
