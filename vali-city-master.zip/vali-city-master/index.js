require('normalize.css');
console.log('hello world');